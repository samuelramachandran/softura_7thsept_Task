﻿using System;
namespace ConsoleApp
{
    interface accomodate
    {

        void resort();

    }

    interface dinner
    {
        void house();

    }
}

